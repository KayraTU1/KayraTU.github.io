# Backup KulAhidi — OAuth Information Site

Minimal public information and privacy-policy website for a personal Restic + Rclone Google Drive backup configuration.

## Deploy on GitHub Pages

1. Create a **new public repository** in your GitHub account called `KayraTU1.github.io` (GitHub may display it in lowercase; match the GitHub username). **Do not change or publish the existing private `kul-ahidi` repository**.
2. Extract this ZIP and upload the **files** (`index.html`, `privacy.html`, `styles.css`, `.nojekyll`, `README.md`) to the repository root using **Add file → Upload files → Commit changes**. Upload the files, not just the `.zip`.
3. In the new repository go to **Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save**.
4. Open `https://kayratu1.github.io/` and `https://kayratu1.github.io/privacy.html` in a signed-out browser window; confirm both pages work and are publicly accessible.
5. In Google Auth Platform → Branding, set homepage and privacy policy to those **verified working URLs**; leave Terms optional. If the console asks for Authorized domains, check whether `kayratu1.github.io` is accepted and whether Search Console ownership is required.
6. Move the OAuth application to **In production** only after checking content and understanding the requested Drive scopes. Google's verification policies can require ownership of the published site/domain; GitHub Pages is not guaranteed to satisfy every domain-ownership check. A custom domain you control may be required.

## Security

- No OAuth client ID, secret, refresh token, Restic password, backup files, game source code, private email or personal details should ever be added to this public repository.
- Website intentionally contains no JavaScript and no login forms.
- Google Drive permission and credential management is handled by Rclone **locally**, not by this website.
- Keep policy accurate if actual data handling changes.
